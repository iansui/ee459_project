EE459 Spring 2019
Team 15
Project name: GeoBuddy
Ling Ye
Brian Suitt
Yi Sui

The main program is in GeoBuddy.h and GeoBuddy.c

Use "sudo make" to compile
Use "sudo make flash" to flash the compiled program onto the microcontroller"
